<div class="dez-post-meta">
    <ul class="d-flex align-items-center">
        <li class="post-date"><i class="fa fa-calendar"></i><?php echo custom_get_the_date(get_the_ID()); ?></li>
        <li class="post-author"><i class="fa fa-user"></i>توسط <a href="#"><?php echo get_the_author(); ?></a> </li>
        <li class="post-comment"><i class="fa fa-comments-o"></i><a href="#"><?php echo get_comments_number(); ?></a> </li>
    </ul>
</div>