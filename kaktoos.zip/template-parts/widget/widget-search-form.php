<div class="wt-widget wt-startsearch">
    <div class="wt-widgettitle">
        <h2> جستجوی خود را شروع کنید </h2>
    </div>
    <div class="wt-widgetcontent">
    <?php get_search_form(); ?>
    </div>
</div>